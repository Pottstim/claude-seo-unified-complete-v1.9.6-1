# Live upgrade notes

## Copy these files into your repo
- `api/__init__.py`
- `api/app.py`
- `api/celery_app.py`
- `api/audit_engine.py`
- `api/tasks.py`

## Requirements to add
Add these to your runtime if missing:
- flask
- flask-cors
- celery
- redis
- psycopg2-binary
- sqlalchemy
- alembic
- prometheus-client
- python-dotenv
- reportlab

## How it works
- `POST /api/v1/audits` queues a job.
- Celery worker runs Playwright audit logic.
- Results are written to `/app/reports/*.json`.
- `GET /api/v1/jobs/<job_id>` returns status/result.
- `GET /api/v1/reports/<filename>` downloads the generated report.

## Test request
```bash
curl -X POST https://seo.liberatedphoenix.com/api/v1/audits \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"url":"https://example.com","client_name":"Example Client"}'
```
