from celery import Celery
import os

celery = Celery(
    'seo_api',
    broker=os.getenv('CELERY_BROKER_URL', 'redis://redis:6379/0'),
    backend=os.getenv('CELERY_RESULT_BACKEND', 'redis://redis:6379/1')
)
celery.conf.task_track_started = True
celery.conf.result_expires = 86400
celery.conf.worker_prefetch_multiplier = 1
celery.conf.task_acks_late = True
