from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import requests
import json
import re


def normalize_text(value):
    return re.sub(r'\s+', ' ', (value or '').strip())


def fetch_robots_and_sitemap(base_url):
    robots_url = urljoin(base_url, '/robots.txt')
    sitemap_url = urljoin(base_url, '/sitemap.xml')
    result = {'robots_txt': None, 'sitemap_xml': None}
    for key, target in [('robots_txt', robots_url), ('sitemap_xml', sitemap_url)]:
        try:
            r = requests.get(target, timeout=15, headers={'User-Agent': 'Mozilla/5.0 SEO Audit Bot'})
            result[key] = {'url': target, 'status_code': r.status_code, 'ok': r.ok}
        except Exception as exc:
            result[key] = {'url': target, 'error': str(exc), 'ok': False}
    return result


def score_audit(data):
    score = 100
    issues = []

    if not data.get('title'):
        score -= 10
        issues.append({'priority': 'high', 'type': 'missing_title', 'message': 'Page title is missing'})
    elif len(data['title']) < 20 or len(data['title']) > 65:
        score -= 4
        issues.append({'priority': 'medium', 'type': 'title_length', 'message': 'Title length is outside recommended range'})

    if not data.get('meta_description'):
        score -= 10
        issues.append({'priority': 'high', 'type': 'missing_meta_description', 'message': 'Meta description is missing'})
    elif len(data['meta_description']) < 70 or len(data['meta_description']) > 160:
        score -= 4
        issues.append({'priority': 'medium', 'type': 'meta_description_length', 'message': 'Meta description length is outside recommended range'})

    if data.get('h1_count', 0) == 0:
        score -= 8
        issues.append({'priority': 'high', 'type': 'missing_h1', 'message': 'No H1 found on page'})
    elif data.get('h1_count', 0) > 1:
        score -= 3
        issues.append({'priority': 'medium', 'type': 'multiple_h1', 'message': 'Multiple H1 tags found'})

    if not data.get('canonical'):
        score -= 5
        issues.append({'priority': 'medium', 'type': 'missing_canonical', 'message': 'Canonical tag missing'})

    if not data.get('schema_count'):
        score -= 5
        issues.append({'priority': 'medium', 'type': 'missing_schema', 'message': 'No schema markup detected'})

    robots = data.get('robots_checks', {})
    if not robots.get('robots_txt', {}).get('ok'):
        score -= 5
        issues.append({'priority': 'medium', 'type': 'missing_robots', 'message': 'robots.txt missing or inaccessible'})
    if not robots.get('sitemap_xml', {}).get('ok'):
        score -= 5
        issues.append({'priority': 'medium', 'type': 'missing_sitemap', 'message': 'sitemap.xml missing or inaccessible'})

    score = max(score, 0)
    return score, issues


def run_live_audit(url):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 900})
        page.goto(url, wait_until='networkidle', timeout=60000)
        html = page.content()
        final_url = page.url
        title = page.title()
        browser.close()

    soup = BeautifulSoup(html, 'lxml')
    meta_description = soup.find('meta', attrs={'name': 'description'})
    canonical = soup.find('link', attrs={'rel': lambda x: x and 'canonical' in x})
    h1_tags = soup.find_all('h1')
    headings = {f'h{i}': len(soup.find_all(f'h{i}')) for i in range(1, 7)}
    schema_tags = soup.find_all('script', attrs={'type': 'application/ld+json'})
    internal_links = 0
    external_links = 0
    parsed_final = urlparse(final_url)

    for a in soup.find_all('a', href=True):
        href = a['href']
        absolute = urljoin(final_url, href)
        parsed = urlparse(absolute)
        if parsed.netloc == parsed_final.netloc:
            internal_links += 1
        elif parsed.scheme in ('http', 'https'):
            external_links += 1

    body_text = normalize_text(soup.get_text(' ', strip=True))
    word_count = len(body_text.split()) if body_text else 0
    robots_checks = fetch_robots_and_sitemap(final_url)

    result = {
        'url': url,
        'final_url': final_url,
        'title': normalize_text(title),
        'title_length': len(normalize_text(title)),
        'meta_description': normalize_text(meta_description.get('content') if meta_description else ''),
        'meta_description_length': len(normalize_text(meta_description.get('content') if meta_description else '')),
        'canonical': canonical.get('href') if canonical else None,
        'h1_count': len(h1_tags),
        'headings': headings,
        'schema_count': len(schema_tags),
        'internal_links': internal_links,
        'external_links': external_links,
        'word_count': word_count,
        'robots_checks': robots_checks,
    }

    score, issues = score_audit(result)
    result['overall_score'] = score
    result['issues'] = issues
    result['warnings'] = [i for i in issues if i['priority'] == 'medium']
    result['critical_issues'] = [i for i in issues if i['priority'] == 'high']
    result['recommendations'] = [
        {'priority': i['priority'], 'action': i['message']} for i in issues
    ]
    return result
