from flask import Flask, jsonify, request, send_file
from celery.result import AsyncResult
from pathlib import Path
import os
from api.celery_app import celery
from api.tasks import run_audit_job, run_competitor_job, run_drift_job

BASE_DIR = Path('/app')
REPORTS_DIR = BASE_DIR / 'reports'
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'change-me')
    app.config['API_TOKEN'] = os.getenv('API_TOKEN', '')

    def authorized(req):
        token = req.headers.get('Authorization', '').replace('Bearer ', '')
        return bool(app.config['API_TOKEN']) and token == app.config['API_TOKEN']

    @app.get('/health')
    def health():
        return jsonify({
            'status': 'healthy',
            'service': 'seo-api',
            'reports_dir': str(REPORTS_DIR),
            'mode': 'live-audit-worker-enabled'
        })

    @app.post('/api/v1/audits')
    def create_audit():
        if not authorized(request):
            return jsonify({'error': 'unauthorized'}), 401
        payload = request.get_json(force=True)
        job = run_audit_job.delay(payload)
        return jsonify({'job_id': job.id, 'status': 'queued'}), 202

    @app.post('/api/v1/competitors')
    def create_competitor():
        if not authorized(request):
            return jsonify({'error': 'unauthorized'}), 401
        payload = request.get_json(force=True)
        job = run_competitor_job.delay(payload)
        return jsonify({'job_id': job.id, 'status': 'queued'}), 202

    @app.post('/api/v1/drift/compare')
    def create_drift():
        if not authorized(request):
            return jsonify({'error': 'unauthorized'}), 401
        payload = request.get_json(force=True)
        job = run_drift_job.delay(payload)
        return jsonify({'job_id': job.id, 'status': 'queued'}), 202

    @app.get('/api/v1/jobs/<job_id>')
    def job_status(job_id):
        if not authorized(request):
            return jsonify({'error': 'unauthorized'}), 401
        result = AsyncResult(job_id, app=celery)
        response = {'job_id': job_id, 'state': result.state}
        if result.successful():
            response['result'] = result.result
        elif result.failed():
            response['error'] = str(result.result)
        return jsonify(response)

    @app.get('/api/v1/reports/<path:filename>')
    def get_report(filename):
        if not authorized(request):
            return jsonify({'error': 'unauthorized'}), 401
        target = REPORTS_DIR / filename
        if not target.exists():
            return jsonify({'error': 'not_found'}), 404
        return send_file(target)

    return app

app = create_app()
