from pathlib import Path
from datetime import datetime
import json
import traceback
from api.celery_app import celery
from api.audit_engine import run_live_audit

REPORTS_DIR = Path('/app/reports')
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

@celery.task(bind=True)
def run_audit_job(self, payload):
    url = payload.get('url')
    client_name = payload.get('client_name', 'client')
    if not url:
        raise ValueError('url is required')

    stamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    safe_name = client_name.replace(' ', '_')
    try:
        result = run_live_audit(url)
        result['client_name'] = client_name
        result['created_at'] = datetime.utcnow().isoformat() + 'Z'
        outfile = REPORTS_DIR / f"{safe_name}_{stamp}_audit.json"
        outfile.write_text(json.dumps(result, indent=2))
        return {
            'status': 'completed',
            'report_file': outfile.name,
            'report_type': 'json',
            'summary': {
                'overall_score': result.get('overall_score'),
                'critical_issues': len(result.get('critical_issues', [])),
                'warnings': len(result.get('warnings', []))
            }
        }
    except Exception as exc:
        error_file = REPORTS_DIR / f"{safe_name}_{stamp}_error.json"
        error_payload = {'error': str(exc), 'traceback': traceback.format_exc(), 'url': url}
        error_file.write_text(json.dumps(error_payload, indent=2))
        raise

@celery.task(bind=True)
def run_competitor_job(self, payload):
    primary_url = payload.get('primary_url')
    competitors = payload.get('competitor_urls', [])
    return {
        'status': 'queued-for-future-enhancement',
        'primary_url': primary_url,
        'competitor_count': len(competitors)
    }

@celery.task(bind=True)
def run_drift_job(self, payload):
    return {
        'status': 'queued-for-future-enhancement',
        'payload': payload
    }
